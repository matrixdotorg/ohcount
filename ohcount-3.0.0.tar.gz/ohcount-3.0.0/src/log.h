#define log_it(log)  {} /* by default, do nothing, to use this to debug
											* uncomment the line below */
//void log_it(char *log);
