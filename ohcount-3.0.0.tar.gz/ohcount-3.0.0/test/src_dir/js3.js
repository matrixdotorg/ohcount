return "'" + this.replace('\\', '\\\\').replace("'", '\\\'') + "'";
// comment
