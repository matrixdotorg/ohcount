p = '"';
/* this should be a comment */
