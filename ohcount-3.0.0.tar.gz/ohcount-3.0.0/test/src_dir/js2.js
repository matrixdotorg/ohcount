<script language="JavaScript1.2">
	/*
	Random Comments
	Foo Foo Foo
	*/
	var submenu=new Array()
	// comment
	// another comment
	submenu[0]='<some_html arg="awesome_arg">foo foo</some_html>'
	//Set delay before submenu disappears after mouse moves out of it (in milliseconds)
	var delay_hide=500
	b=0
</script>
