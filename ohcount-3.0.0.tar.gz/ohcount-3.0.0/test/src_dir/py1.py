# some python code
# lorem
# ipsum
# foo

class Foo:
  """
  This is a foo class
  It doesn't do anything
  Therefore this doc comment is pointless
  """

  def __init__(self, bar):
    """short doc comment"""
    print(bar)

  def string(self):
    print('This is a string')
