/* new */
#include 'foo.c'
/* common */
int do_stuff(old_code) {
	int common;
	int new_var;
}
