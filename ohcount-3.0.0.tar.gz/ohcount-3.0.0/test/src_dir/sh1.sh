#!/bin/sh

ls -la
# comment
echo hello #comment
