/* old */
#include 'foo.c'
/* common */
int do_stuff(old_code) {
	int common;
	int old_var;
}
