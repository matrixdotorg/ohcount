require 'test/unit'
require File.dirname(__FILE__) + '/../../../../ruby/gestalt'

class RuleTest < Test::Unit::TestCase

	def test_here

	end
end


