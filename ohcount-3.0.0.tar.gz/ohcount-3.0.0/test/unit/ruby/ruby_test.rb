require File.dirname(__FILE__) + '/test_helper.rb'
require File.dirname(__FILE__) + '/source_file_list_test.rb'
require File.dirname(__FILE__) + '/source_file_test.rb'
require File.dirname(__FILE__) + '/gestalt/gestalt_test'
