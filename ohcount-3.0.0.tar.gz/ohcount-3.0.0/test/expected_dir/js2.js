javascript	code	<script language="JavaScript1.2">
javascript	comment		/*
javascript	comment		Random Comments
javascript	comment		Foo Foo Foo
javascript	comment		*/
javascript	code		var submenu=new Array()
javascript	comment		// comment
javascript	comment		// another comment
javascript	code		submenu[0]='<some_html arg="awesome_arg">foo foo</some_html>'
javascript	comment		//Set delay before submenu disappears after mouse moves out of it (in milliseconds)
javascript	code		var delay_hide=500
javascript	code		b=0
javascript	code	</script>
