haskell	comment	    {-
haskell	comment	      {- 3 lines of comments total! -}
haskell	blank	
haskell	comment	    -}
haskell	blank	
