c	code	p = '"';
c	comment	/* this should be a comment */
