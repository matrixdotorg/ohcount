ocaml	comment	(** documentation *)
ocaml	code	print_string "Hello world!\n";;
ocaml	comment	(**/**)
ocaml	comment	(* extra comment *)
ocaml	blank	
ocaml	comment	(* multiline
ocaml	comment	   comment*)
ocaml	blank	
ocaml	comment	(* recursion in (* a
ocaml	comment	   comment *) to complicate things *)
