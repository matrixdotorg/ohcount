c	comment	/* old */
c	code	#include 'foo.c'
c	comment	/* common */
c	code	int do_stuff(old_code) {
c	code		int common;
c	code		int old_var;
c	code	}
