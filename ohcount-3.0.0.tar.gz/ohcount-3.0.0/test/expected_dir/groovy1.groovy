groovy	comment	//hello.groovy
groovy	code	println "hello, world"
groovy	code	for (arg in this.args ) {
groovy	code	  println "Argument:" + arg;
groovy	code	}
groovy	comment	// this is a comment
groovy	comment	/* a block comment, commenting out an alternative to above:
groovy	comment	this.args.each{ arg -> println "hello, ${arg}"}
groovy	comment	*/
