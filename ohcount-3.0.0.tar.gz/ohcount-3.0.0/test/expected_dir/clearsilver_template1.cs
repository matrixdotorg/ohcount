html	code	<html>
html	code	<body>
clearsilver	comment	<p><?cs #comment ?></p>
clearsilver	code	<p><?cs set:count = 0 ?></p>
html	code	</body>
html	code	</html>
