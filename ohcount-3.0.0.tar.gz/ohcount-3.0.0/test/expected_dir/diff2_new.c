c	comment	/* new */
c	code	#include 'foo.c'
c	comment	/* common */
c	code	int do_stuff(old_code) {
c	code		int common;
c	code		int new_var;
c	code	}
