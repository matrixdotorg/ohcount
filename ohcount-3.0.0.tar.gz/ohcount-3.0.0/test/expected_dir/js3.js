javascript	code	return "'" + this.replace('\\', '\\\\').replace("'", '\\\'') + "'";
javascript	comment	// comment
