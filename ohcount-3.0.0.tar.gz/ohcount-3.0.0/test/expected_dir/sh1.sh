shell	comment	#!/bin/sh
shell	blank	
shell	code	ls -la
shell	comment	# comment
shell	code	echo hello #comment
