python	comment	# some python code
python	comment	# lorem
python	comment	# ipsum
python	comment	# foo
python	blank	
python	code	class Foo:
python	comment	  """
python	comment	  This is a foo class
python	comment	  It doesn't do anything
python	comment	  Therefore this doc comment is pointless
python	comment	  """
python	blank	
python	code	  def __init__(self, bar):
python	comment	    """short doc comment"""
python	code	    print(bar)
python	blank	
python	code	  def string(self):
python	code	    print('This is a string')
