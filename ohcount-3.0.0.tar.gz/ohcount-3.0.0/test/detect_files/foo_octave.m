function foo
  ## a comment
endfunction
