#include <string>

std::string foo();
