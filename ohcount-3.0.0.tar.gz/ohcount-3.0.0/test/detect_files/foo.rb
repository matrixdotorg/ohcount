# a ruby script
File.open("blah") do |io|
  a = io.read
end
