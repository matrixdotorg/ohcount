// c file
int function_a(void) {
	int x;
}
