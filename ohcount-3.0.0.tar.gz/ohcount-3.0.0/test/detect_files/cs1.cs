// Class to test it all
public class SomeClass
{
    public static void Main () {
        SomeClass x = new SomeClass ();
    }
}
