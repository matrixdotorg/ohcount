namespace monkey {
	template <typename> struct Monkey;
}

