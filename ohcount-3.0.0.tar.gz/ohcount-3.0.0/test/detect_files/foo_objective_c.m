// c_comment
i = 2;
