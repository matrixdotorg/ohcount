function foo = b
% a comment
end
