#include <foo/foo.hh>

foo::Foo get_foo();

