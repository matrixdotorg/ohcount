(** documentation *)
print_string "Hello world!\n";;
(**/**)
(* extra comment *)

(* multiline
   comment*)

(* recursion in (* a
   comment *) to complicate things *)
