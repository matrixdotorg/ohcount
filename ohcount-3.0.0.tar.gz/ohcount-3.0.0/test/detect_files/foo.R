dummy<-function() {
# A dummy function to test the R language parser.
	1.0
}

