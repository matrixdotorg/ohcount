<?php

/**
 * @package Sample
 */
class Sample
{
}

?>
