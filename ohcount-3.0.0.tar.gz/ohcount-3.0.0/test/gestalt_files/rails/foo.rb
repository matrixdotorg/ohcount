# we're impersonating a rails app
RAILS_ROOT = '/'
some_rails_code = "true"
