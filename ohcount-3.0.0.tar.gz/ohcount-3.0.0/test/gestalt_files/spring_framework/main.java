class JavaClass
{
	int i = 1;
	int i = 2;
	int i = 3;
}

