# this is ruby code
class Foo
	attr_reader :bar
end
