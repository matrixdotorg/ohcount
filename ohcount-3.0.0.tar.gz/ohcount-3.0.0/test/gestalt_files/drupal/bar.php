<?php
	$r = 5;
	$button = drupal_render($form['continue_shopping']);
?>
