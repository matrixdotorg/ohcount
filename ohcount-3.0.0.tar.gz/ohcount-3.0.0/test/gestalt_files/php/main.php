<?php
require_once './libraries/common.inc.php';
require_once './libraries/header.inc.php';
require_once './libraries/footer.inc.php';
?>
