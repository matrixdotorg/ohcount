/*******************************************************************************
 * Gibberish Code Copyrighted Just For The Hell Of It.
 ******************************************************************************/
 package net.ohloh.www;

 import java.text.SimpleDateFormat;
 import java.util.Map;
 import org.eclipse.core.lotsa_stuff;

 public class AptPlugin extends Plugin {
	   public static final String PLUGIN_ID = "org.eclipse.jdt.apt.core"; //$NON-NLS-1$
 }
