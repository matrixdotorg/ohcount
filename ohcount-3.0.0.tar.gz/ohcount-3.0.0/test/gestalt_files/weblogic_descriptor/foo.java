/* Just a comment */
{
	return a_few_lines_of_java_to_trigger_the_java_platform();
}
