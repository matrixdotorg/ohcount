<?php

class Sample
{
 $foo = '/moodle/blocks/';
}

?>
