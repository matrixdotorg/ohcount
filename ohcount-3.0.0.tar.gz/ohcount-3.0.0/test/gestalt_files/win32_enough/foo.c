// another commented WndProc
WndProc *wndproc;

