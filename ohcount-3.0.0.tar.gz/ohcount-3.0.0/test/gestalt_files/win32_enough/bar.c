// a commented WndProc
WndProc *wndproc;

