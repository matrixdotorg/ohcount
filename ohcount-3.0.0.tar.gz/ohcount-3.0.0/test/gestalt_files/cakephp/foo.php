<?php
setcookie("user", "Alex Porter", time()+60*60*24*30*365;
$i = 5;
$s = 'CAKE_CORE_INCLUDE_PATH';
?>
