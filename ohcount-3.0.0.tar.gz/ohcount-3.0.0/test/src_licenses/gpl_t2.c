// This code is licensed under GPL.
