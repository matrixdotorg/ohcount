// Lesser GPL
