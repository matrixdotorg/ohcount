// Qt Public License (QPL)
