// Nokia Open Source License
