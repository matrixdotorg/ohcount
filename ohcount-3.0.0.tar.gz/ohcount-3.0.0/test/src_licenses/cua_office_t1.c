/*
 * CUA Office Public License Version 1.0
 */
