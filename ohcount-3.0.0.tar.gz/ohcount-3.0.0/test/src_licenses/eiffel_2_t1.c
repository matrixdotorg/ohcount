// Eiffel Forum License V2.0
