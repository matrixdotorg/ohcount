// Historical Permission Notice and Disclaimer
