// Eiffel Forum License
