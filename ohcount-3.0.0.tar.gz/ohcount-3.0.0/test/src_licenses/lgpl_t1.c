// GNU Library or "Lesser" General Public License (LGPL)
