// Nethack General Public License
