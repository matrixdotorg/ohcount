// The line break and comment syntax should not disrupt the license match
// GNU General
// Public License
