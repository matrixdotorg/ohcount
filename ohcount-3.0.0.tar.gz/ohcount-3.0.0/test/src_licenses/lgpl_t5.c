// Library GPL
