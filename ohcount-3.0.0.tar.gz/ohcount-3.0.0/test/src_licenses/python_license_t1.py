"""
    Python license
"""
