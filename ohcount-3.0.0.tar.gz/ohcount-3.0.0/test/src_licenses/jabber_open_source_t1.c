// Jabber Open Source License
