#region License
// <copyright owner="Cetin Sert">
//
//      Tenka Text
//      Open-source Corpus Analysis Software
//      Copyright (c) 2006, 2007 Cetin Sert.
//
//
//
//      GNU General Public License Version 3 Banner
//
//      This program is free software: you can redistribute it and/or modify
//      it under the terms of the GNU General Public License as published by
//      the Free Software Foundation, either version 3 of the License, or
//      (at your option) any later version.
//
//      This program is distributed in the hope that it will be useful,
//      but WITHOUT ANY WARRANTY; without even the implied warranty of
//      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//      GNU General Public License for more details.
//
//      You should have received a copy of the GNU General Public License
//      along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//
//
//      Commercial Licensing
//
//      Tenka Text is released under GNU General Public License Version 3
//      which does not permit any kind of commercial use of Tenka Text or
//      any parts of it. This restriction applies even if you modify or
//      translate the program or parts of it into another programming
//      language. For more information see License.txt.
//
//      Parties interested in inquiring about commercial licensing of Tenka Text
//      should contact the copyright owner for more information.
//
//      Cetin Sert
//      INF 521, 4-6-2
//      69120 Heidelberg
//      Baden-Wuerttemberg
//      Germany
//
//      cetin.sert@gmail.com
//
//      +49 151 177 610 28
//
// </copyright>

#endregion

using System;

