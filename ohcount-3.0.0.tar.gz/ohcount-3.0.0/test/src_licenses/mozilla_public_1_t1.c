// Mozilla Public License 1.0 (MPL)
