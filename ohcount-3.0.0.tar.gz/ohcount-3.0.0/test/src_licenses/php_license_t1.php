<?php
/*
	PHP License
*/
?>
