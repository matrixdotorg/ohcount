/* Attribution Assurance Licenses */
