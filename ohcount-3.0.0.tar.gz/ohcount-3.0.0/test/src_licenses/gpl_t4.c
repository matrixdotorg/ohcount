//@license    GPLv2 http://files.syscp.org/misc/COPYING.txt
