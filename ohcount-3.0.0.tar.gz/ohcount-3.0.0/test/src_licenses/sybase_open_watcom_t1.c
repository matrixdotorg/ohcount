// Sybase Open Watcom Public License 1.0
