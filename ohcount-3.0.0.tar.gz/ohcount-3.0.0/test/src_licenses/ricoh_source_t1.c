// Ricoh Source Code Public License
