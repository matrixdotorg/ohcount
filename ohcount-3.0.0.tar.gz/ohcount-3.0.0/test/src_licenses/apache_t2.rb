# Apache Software License 1.0
