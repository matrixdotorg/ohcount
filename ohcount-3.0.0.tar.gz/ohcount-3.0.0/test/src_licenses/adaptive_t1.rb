# Adaptive Public License
